import Loader from "@/components/loading"
const Loading = () => {
    return (
        <Loader />
    )
}

export default Loading